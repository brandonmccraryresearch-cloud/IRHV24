Remote Tools
============

Remote tools are external services, APIs, or tools running on separate servers that are accessed via MCP (Model Context Protocol) and integrated with ToolUniverse.

.. toctree::
   :maxdepth: 2
   :caption: Remote Tools

   tutorial
   mcp_integration