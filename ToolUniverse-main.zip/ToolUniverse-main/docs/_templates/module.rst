{{ fullname }}
{{ underline }}

.. currentmodule:: {{ module }}

.. automodule:: {{ objname }}
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__,__call__,__str__,__repr__
   :imported-members:
