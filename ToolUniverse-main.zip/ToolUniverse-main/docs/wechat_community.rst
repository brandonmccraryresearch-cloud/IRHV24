WeChat Community
================

Join our WeChat community to connect with other ToolUniverse users, get help, and share your experiences!

**WeChat QR Code**: Visit `https://aiscientist.tools/wechat <https://aiscientist.tools/wechat>`_ to get the latest WeChat QR code for joining our community.

Alternative Ways to Connect
---------------------------

If you prefer other communication channels:

- **Slack**: `Join our Slack community <https://join.slack.com/t/tooluniversehq/shared_invite/zt-3dic3eoio-5xxoJch7TLNibNQn5_AREQ>`_
- **GitHub Discussions**: `GitHub Discussions <https://github.com/mims-harvard/ToolUniverse/discussions>`_
- **LinkedIn**: `Follow us on LinkedIn <https://www.linkedin.com/in/tooluniverse-at-harvard-b9aa88385/>`_
- **X (Twitter)**: `Follow us on X <https://x.com/ScientistTools>`_

We look forward to welcoming you to our community!
